package com.greatlearning.StudentMgmPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentMgmPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
